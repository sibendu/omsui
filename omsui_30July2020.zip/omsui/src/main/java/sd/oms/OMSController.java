package sd.oms;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

@Controller
public class OMSController {
	
	@Autowired
	private CustomerRepository customerRepository;
	
	@Autowired
	private OrderRepository orderRepository;
	
	public String getJson() {
		String products = null;
		try {
			InputStream fis = this.getClass().getClassLoader()
                    .getResourceAsStream("products.json");
			
			//FileInputStream fis = new FileInputStream(in); 
			byte[] b = new  byte[10000];
			fis.read(b);
			fis.close();
			products = new String(b).trim();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return products;
	}

	@PostMapping("/login")
	public String login(@RequestParam(name = "phone", required = true) String phone,
			Model model, HttpSession httpSession) {
		
		Optional<Customer> customer = customerRepository.findById(phone);
		String productsJson = getJson();
		//System.out.println(productsJson);
		
		customer.ifPresent(cust -> {
			httpSession.setAttribute("customer", cust);
			httpSession.setAttribute("products", productsJson);
			
			//ArrayList<Order> orders =  getOrders(cust.getId());
			//model.addAttribute("orders", orders);
			
		});
		
		if(!customer.isPresent()) {
			model.addAttribute("message", "Invalid login, please contact Admin");
			return "error";
		}
		
		return "home";//showOrder(model, httpSession);
	}

	@GetMapping("/order")
    public String showOrder(Model model, HttpSession httpSession) {
		Customer cust = (Customer)httpSession.getAttribute("customer");
		ArrayList<Order> orders =  getOrders(cust.getId());
		model.addAttribute("orders", orders);
		
		System.out.println("Going to orders");
        return "orders";
    }
	
	@GetMapping("/home")
    public String showProducts(Model model, HttpSession httpSession) {
		System.out.println("Going to products");
        return "home";
    }
	
	@GetMapping("/cart")
    public String showCart(Model model, HttpSession httpSession) {
		System.out.println("Going to cart");
        return "cart";
    }
	
	@GetMapping("/seller")
    public String showSeller(Model model, HttpSession httpSession) {
		Customer cust = (Customer)httpSession.getAttribute("customer");
		Optional<Customer> seller = customerRepository.findById(cust.getSeller());
		
		if(seller.isPresent()) {
			model.addAttribute("seller", seller.get()); 
			System.out.println("Going to seller");
		}else {
			System.out.println("WARNING::: No seller mapped to buyer");
			model.addAttribute("message", "You have not selected a seller yet. Please contact admin.");
			return "error"; 
		}
        return "seller";
    }
	
	@PostMapping("/order")
	public String submitOrder(@RequestParam(name = "order", required = true) String orderPayload,
			Model model, HttpSession httpSession) {
		
		System.out.println("Received order :: "+orderPayload);
		
		Customer cust = (Customer)httpSession.getAttribute("customer");
		
		
		final GsonBuilder gsonBuilder = new GsonBuilder();
		final Gson gson = gsonBuilder.create();

		//ItemDTO[] items = gson.fromJson(orderPayload, ItemDTO[].class);
		OrderDTO inputOrder = gson.fromJson(orderPayload, OrderDTO.class);
		ItemDTO[] items = inputOrder.getItems();
		System.out.println("Order has = "+items.length+" items; inst = "+inputOrder.getInstruction());
		for (int i = 0; i < items.length; i++) {
			System.out.println(items[i].getDescription());
		}
		
		Order order = new Order("O"+Math.random(), inputOrder.getInstruction(), OMSUtil.ORDER_STATUS_NEW, null, cust.getId(), cust.getSeller()); 	
	  
    	for (ItemDTO item : items) {   		
    		order.getItems().add(new Item("I"+Math.random(), item.getCode(), item.getName(), item.getDescription(), item.getQuantity(), item.getPrice(),item.getUnit(), null,null,order));
 		}
    	
	    orderRepository.save(order);	
		System.out.println("Order saved successfully.");
		
		ArrayList<Order> orders =  getOrders(cust.getId());
		model.addAttribute("orders", orders);
		
		model.addAttribute("clearCart", true);
		
		model.addAttribute("message", "Thank you for placing Order# "+order.getId()+", Seller is informed and will process it.");
		
		return "orders";
	}
	
	@GetMapping("/logout")
    public String logout(Model model, HttpSession httpSession) {
		httpSession.removeAttribute("customer");
		httpSession.invalidate();
		System.out.println("Logging off.");
        return "redirect:/";
    }
	
	@GetMapping("/signup")
    public String signup(Model model, HttpSession httpSession) {
		System.out.println("Sign Up");
        return "signup";
    }
	
	public ArrayList<Order> getOrders(String user){
		ArrayList<Order> orders = new ArrayList<>();
		long now = new Date().getTime();
		Iterable<Order>	allOrders = orderRepository.findByCustomerId(user);
		for (Order order : allOrders) {
			//Order status new or processing  
			if(OMSUtil.ORDER_STATUS_NEW.equals(order.getStatus()) || OMSUtil.ORDER_STATUS_PROCESSING.equals(order.getStatus())) {
				orders.add(order);
			}
			
			//If order is cancelled or completed, check date
			if(OMSUtil.ORDER_STATUS_COMPLETED.equals(order.getStatus()) || OMSUtil.ORDER_STATUS_CANCELLED.equals(order.getStatus())) {	
				long age = TimeUnit.DAYS.convert(Math.abs(now - order.getCreated().getTime()), TimeUnit.MILLISECONDS);
				if(age < 30) { // Only within last 30 days
					orders.add(order);
				}
			}
		}
		return orders;
	}
	
	@GetMapping("/order/view/{id}")
    public String viewOrder(
    		@PathVariable(name = "id", required = true) String id,
    		Order order, Model model, HttpSession httpSession) {
		
		System.out.println("viewOrder :: order_id = "+id);
        Optional<Order> thisOrder = orderRepository.findById(id);

        if(thisOrder.isPresent()) {
            System.out.println("Order retrieved");
        	order = thisOrder.get();
        }
        
        httpSession.setAttribute("order", order);   
        model.addAttribute("order", order);
		return "order";
    }
	
	@GetMapping("/order/delete/{id}")
    public String deleteOrder(
    		@PathVariable(name = "id", required = true) String id,
    		Model model, HttpSession httpSession) {
		
		System.out.println("deleteOrder :: order_id = "+id);
		Customer customer = (Customer)httpSession.getAttribute("customer");
		ArrayList<Order> orders =  null;
        Optional<Order> order = orderRepository.findById(id);

        if(order.isPresent()) {
        	Order ord = order.get();
        	if(ord.getStatus() != null && !ord.getStatus().equals(OMSUtil.ORDER_STATUS_NEW)) {
        		//Only order in NEW state can be cancelled i.e. seller has not started processing
        		model.addAttribute("message", "Order is already under processing or processed; please contact your seller for any change.");
        		
        		orders =  getOrders(customer.getId());
        		model.addAttribute("orders", orders);
        		
        		return "home";
        	}
        	orderRepository.delete(ord);
        }
        System.out.println("Order deleted");
        
        model.addAttribute("message", "Order deleted successfully.");
        
        
        orders =  getOrders(customer.getId());
		model.addAttribute("orders", orders);
        
		return "orders";
    }
	
	/* NOT NEEDED */
	
	/*
	@GetMapping("/neworder")
    public String showOrderForm(Order order, HttpSession httpSession) {
		
		System.out.println("I am here");
		order = new Order();
		order.setStatus(OMSUtil.ORDER_STATUS_NEW);

		httpSession.setAttribute("order", order);  
        return "neworder";
    }
	
	@PostMapping("/addorder")
    public String addOrder(Order order, Model model, HttpSession httpSession) {
		
		order = (Order)httpSession.getAttribute("order");  
		Customer customer = (Customer)httpSession.getAttribute("customer");
		Optional<Customer> seller = customerRepository.findById(customer.getSeller());
		
        System.out.println("Order id: "+order.getId());
        System.out.println("Items = "+order.getItems().size());
        
        if(order.getId() == null) { 
        	order.setId("O"+Math.random());
        	order.setStatus(OMSUtil.ORDER_STATUS_NEW);
        	order.setCreated(new Date());
        	order.setCustomerId(customer.getId());
        	order.setSellerId(seller.get().getId());
        	
        	List<Item> items = order.getItems();
        	for (Item item : items) {
				item.setOrder(order);
			}
        }
        orderRepository.save(order);
        
//        Optional<Order> ord = orderRepository.findById(order.getId());
//        if(ord.isPresent()) {
//        	orderRepository.refresh(ord.get());
//        }
        
        ArrayList<Order> orders =  getOrders(customer.getId());
		model.addAttribute("orders", orders);
		
		String message = "Thank you for placing Order# "+order.getId()+". ";
		if(seller.isPresent()){
			message = message +  seller.get().getName() +" ("+seller.get().getPhone() +") is intimated and will process it soon.";			
		}
		
		httpSession.removeAttribute("order"); 
		System.out.println("Order saved successfully, and session cleaned");
        
        model.addAttribute("message", message);

        return "dashboard";
    }
	
	@GetMapping("/order/view/{id}")
    public String viewOrder(
    		@PathVariable(name = "id", required = true) String id,
    		Order order, Model model, HttpSession httpSession) {
		
		System.out.println("viewOrder :: order_id = "+id);
        Optional<Order> thisOrder = orderRepository.findById(id);

        if(thisOrder.isPresent()) {
            System.out.println("Order retrieved");
        	order = thisOrder.get();
        }
        
        httpSession.setAttribute("order", order);   
        model.addAttribute("order", order);
		return "neworder";
    }
	
	@GetMapping("/order/item/delete/{id}")
    public String deleteOrderItem(
    		@PathVariable(name = "id", required = true) String id,
    		Order order, Model model, HttpSession httpSession) {
		
		System.out.println("deleteOrderItem :: item_id = "+id);
		Order session_order = (Order)httpSession.getAttribute("order");
		List<Item> items = session_order.getItems();
        for (Item item : items) {
			if(item.getId().equals(id)) {
				items.remove(item);
				break;
			}
		}
		
        //Sync order object in screen and session 
        order = session_order;
        model.addAttribute("order", order);
        
		return "neworder";
    }
	
	@PostMapping("/addorderitem")
    public String addOrderIem(
    		@RequestParam(name = "description", required = true) String description,
    		@RequestParam(name = "quantity", required = true) String quantity,
    		@RequestParam(name = "item_instruction", required = false) String item_instruction,
    		Order order, Model model, HttpSession httpSession) {
		
        System.out.println("I am here; Order id: "+order.getId());
        
        Order session_order = (Order)httpSession.getAttribute("order");  
        
        if(session_order == null) { // This is the first item being added to this order
        	session_order = order; 
        }
        
        //Set values in order object stored in session 
        session_order.setInstruction(order.getInstruction());
        session_order.getItems().add(new Item("I"+Math.random(), null, description, quantity, null, item_instruction, null, session_order));
        
        httpSession.setAttribute("order", session_order);
        
        //Sync order object in screen and session 
        order = session_order;
        model.addAttribute("order", order);
        //model.addAttribute("message", "Item added to your order");
        
        return "neworder";
    }
	*/
}
