package sd.oms;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
[
 {"id":"1002","code":"abc1002","name":"Deradun","description":"Deradun Rice","price":"70","unit":"kg","quantity":4},
 {"id":"2001","code":"abc2001","name":"Fortune","description":"Fortune","price":"125.75","unit":"pack","quantity":2}]
		*/
		
		String x = "[{\"id\":\"1002\",\"code\":\"abc1002\",\"name\":\"Deradun\",\"description\":\"Deradun Rice\",\"price\":\",,70\",\"unit\":\"kg\",\"quantity\":4},{\"id\":\"2001\",\"code\":\"abc2001\",\"name\":\"Fortune\",\"description\":\"Fortune\",\"price\":\",,125.75\",\"unit\":\"pack\",\"quantity\":2}]";
		
		final GsonBuilder gsonBuilder = new GsonBuilder();
		final Gson gson = gsonBuilder.create();

		ItemDTO[] order = gson.fromJson(x, ItemDTO[].class);
		for (int i = 0; i < order.length; i++) {
			System.out.println(order[i].getDescription());
		}
		
		//OrderDTO order = gson.fromJson(x, OrderDTO.class);
		
		System.out.println(order);
		
	}

}
