package sd.oms;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

public interface OrderRepository extends CustomRepository<Order, String> {
	
	List<Order> findByCustomerId(String customerId);
}
